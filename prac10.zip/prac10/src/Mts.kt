abstract class Mts : OperatorInfo(){
    override val name = "МТС"
    override val minute = 2.55

    override val zone = false
}