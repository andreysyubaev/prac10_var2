abstract class OperatorInfo : OperatorMain {
    abstract val name: String
    abstract val minute: Double

    open fun Info(){
        println("$name - $minute рублей в минуту")
    }

    override val zone = false
    override fun StartWork() {
        Info()
    }
}