interface OperatorMain : Work {
    val zone: Boolean
    get() = false

    open fun StartWork(){
        val q: Double
    }
    open fun isWork() : Boolean{
        if (cant == "нет связи") return false
        return true
    }
}