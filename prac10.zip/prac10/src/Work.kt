interface Work {
    val cant: String
        get() = "нет связи"
}